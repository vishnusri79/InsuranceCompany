package model;

import java.time.LocalDate;

public class Claim {
    private int claimId;
    private int userId; // User who submitted the claim
    private int registeredProductId; // Product associated with the claim
    private LocalDate dateOfClaim;
    private String description;
    private String status;
    private LocalDate approvalDate;
    private String rejectionReason;

    public Claim() {
        // Default constructor
    }

    // Constructor with parameters
    public Claim(int claimId, int userId, int registeredProductId, LocalDate dateOfClaim, String description, String status, LocalDate approvalDate, String rejectionReason) {
        this.claimId = claimId;
        this.dateOfClaim = dateOfClaim;
        this.description = description;
        this.status = status;
        this.approvalDate = approvalDate;
        this.rejectionReason = rejectionReason;
    }

    // Getters and setters for all attributes
    public int getClaimId() {
        return claimId;
    }

    public void setClaimId(int claimId) {
        this.claimId = claimId;
    }

    public int getUser() {
        return userId;
    }

    public void setUser(int user) {
        this.userId = user;
    }

    public int getRegisteredProductId() {
        return registeredProductId;
    }

    public void setRegisteredProduct(int registeredProductId) {
        this.registeredProductId = registeredProductId;
    }

    public LocalDate getDateOfClaim() {
        return dateOfClaim;
    }

    public void setDateOfClaim(LocalDate dateOfClaim) {
        this.dateOfClaim = dateOfClaim;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public LocalDate getApprovalDate() {
        return approvalDate;
    }

    public void setApprovalDate(LocalDate approvalDate) {
        this.approvalDate = approvalDate;
    }

    public String getRejectionReason() {
        return rejectionReason;
    }

    public void setRejectionReason(String rejectionReason) {
        this.rejectionReason = rejectionReason;
    }
    
}


