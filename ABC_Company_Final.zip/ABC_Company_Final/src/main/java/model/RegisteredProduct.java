package model;

import java.time.LocalDate;

public class RegisteredProduct {
	
   
	private int registrationId;
    private String productName; // Product that was registered
    private String category;
    private String serialNo;
    private LocalDate purchaseDate;
    private int claimsLeft;  // No. of Claims left

    
    public RegisteredProduct(int registrationId, String productName, String category, String serialNo, LocalDate purchaseDate, int claimsLeft) {
		super();
		this.registrationId = registrationId;
		this.productName = productName;
		this.serialNo = serialNo;
		this.purchaseDate = purchaseDate;
		this.category = category;
		this.claimsLeft = claimsLeft;
	}
    
	

	public RegisteredProduct() {
		// TODO Auto-generated constructor stub
	}

	public int getRegistrationId() {
		return registrationId;
	}
	
	public void setRegistrationId(int registrationId) {
		this.registrationId = registrationId;
	}
	

//	for the productName
	public String getProductName() {
		return productName;
	}

	public void setProductName(String productName) {
		this.productName = productName;
	}
	
	
	public String getCategory() {
		return category;
	}

	public void setCategory(String category) {
		this.category = category;
	}
	
	
	public String getSerialNo() {
		return serialNo;
	}
	
	public void setSerialNo(String serialNo) {
		this.serialNo = serialNo;
	}
	
	

	public LocalDate getPurchaseDate() {
		return purchaseDate;
	}

	public void setPurchaseDate(LocalDate purchaseDate) {
		this.purchaseDate = purchaseDate;
	}
	
	
	
	public int getClaimsLeft() {
		return claimsLeft;
		
	}
	public void setClaimsLeft(Integer claimsLeft) {
		this.claimsLeft = claimsLeft;
		
	}
	





}
