package controller;

import java.io.IOException;
import java.sql.SQLException;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import dbHelpers.Authenticator;
import dbHelpers.ReadUser;
import model.User;
import model.RegisteredProduct;

/**
 * Servlet implementation class UserLogin
 */
@WebServlet("/UserLogin")
public class UserLogin extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public UserLogin() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doPost(request, response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// get User Login Details
				String username = request.getParameter("username");
				String password = request.getParameter("password");
				RequestDispatcher rd = null;
		 
				Authenticator authenticator = new Authenticator();
				String result = authenticator.authenticateUser(username, password);
				if (result.equals("success")) {
					rd = request.getRequestDispatcher("/userDashboard.jsp");
					
					ReadUser ru = new ReadUser();
					try {
						List<RegisteredProduct> registeredProducts = ru.doReadUserProducts(username);
						User currentUser = ru.doReadUserInfo(username);
						
						 // Set registeredProducts as an attribute in the request object
				        request.setAttribute("registeredProducts", registeredProducts);
				        
				        // Store the user object in the session
			            HttpSession session = request.getSession();
			            session.setAttribute("user", currentUser);
						
						 
				        
						
					} catch (SQLException e) {
						
					e.printStackTrace();
					}
					
				
				} else {
					String errorMsg = "<p>Username or Password Incorrect!</p>";
				
					rd = request.getRequestDispatcher("/userlogin.jsp");
					
					request.setAttribute("errorMsg", errorMsg);
				}
				rd.forward(request, response);
			}
	

}
