package controller;

import java.io.IOException;
import java.sql.SQLException;
import java.time.LocalDate;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import dbHelpers.AddClaim;
import model.Claim;
import model.User;

@WebServlet("/SubmitClaim")
public class SubmitClaim extends HttpServlet {
    private static final long serialVersionUID = 1L;

    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
    	// Retrieve userId from session
     //   int userId = Integer.parseInt(request.getSession().getAttribute("user_id").toString());
        
        // Retrieve registrationId from request parameter
     //   int registrationId = Integer.parseInt(request.getParameter("registration_id"));
        
        // Get current date for dateOfClaim
        LocalDate dateOfClaim = LocalDate.now();
        
        // Retrieve description from request parameter
        String description = request.getParameter("issue");
        System.out.println(description);
        
        
        // Set initial status to "pending"
        String status = "pending";
        
        // Set approvalDate and rejectionReason to null initially
        LocalDate approvalDate = null;
        String rejectionReason = null;
        
        //Get userId from session (assuming it's stored in the session)
         HttpSession session = request.getSession();
         User currentUser = new User();
         currentUser = (User)session.getAttribute("user");

        // Create a new Claim object
        Claim claim = new Claim();
         
        claim.setDateOfClaim(dateOfClaim);
        claim.setDescription(description);
        claim.setStatus(status);
        claim.setApprovalDate(approvalDate);
        claim.setRejectionReason(rejectionReason);

        AddClaim addClaim = new AddClaim();

        try {
            addClaim.addClaim(claim);
            System.out.println("Claim added successfully");
            // Redirect to user_claim_list.jsp
            response.sendRedirect("user_claim_list.jsp");
        } catch (SQLException e) {
            e.printStackTrace();
            // Handle database error
            response.sendError(HttpServletResponse.SC_INTERNAL_SERVER_ERROR);
        }
    }
}
