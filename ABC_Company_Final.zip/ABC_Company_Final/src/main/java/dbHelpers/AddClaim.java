package dbHelpers;

import java.io.InputStream;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.Properties;

import javax.servlet.http.HttpSession;
import javax.servlet.http.HttpServletRequest;


import model.Claim;
import model.User;

public class AddClaim {
    private Connection conn;
    private PreparedStatement pStmt;

    public AddClaim() {
        Properties properties = new Properties();
        InputStream in;

        try {
            in = getClass().getResourceAsStream("dbConfig.properties");
            properties.load(in);

            String driver = properties.getProperty("jdbc.driver");

            if (driver != null) {
                Class.forName(driver);
            }
            String url = properties.getProperty("jdbc.url");
            String username = properties.getProperty("jdbc.username");
            String password = properties.getProperty("jdbc.password");

            conn = DriverManager.getConnection(url, username, password);
            System.out.println("Connection Established");

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void addClaim(Claim claim) throws SQLException {
    	
    	
        

       
        
        String sql = "INSERT INTO Claims (user_id, registration_id, date_of_claim, description, status) VALUES (?, ?, ?, ?, ?)";

        try {
            pStmt = conn.prepareStatement(sql);
            pStmt.setInt(1, 2);
            pStmt.setInt(2, 17);
            pStmt.setDate(3, java.sql.Date.valueOf(claim.getDateOfClaim()));
            pStmt.setString(4, claim.getDescription());
            pStmt.setString(5, claim.getStatus());
            
            

            
            int rowsAffected = pStmt.executeUpdate();
            System.out.println(rowsAffected + " row(s) affected");

        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            if (pStmt != null) {
                pStmt.close();
            }
            if (conn != null) {
                conn.close();
            }
        }
    }
}
