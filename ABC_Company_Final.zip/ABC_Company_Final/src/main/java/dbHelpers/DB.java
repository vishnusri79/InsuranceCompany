package dbHelpers;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class DB {
	private static Connection conn;


	
	/* 
	 * [TASK OUTSIDE ECLIPSE]
	 * Create a database called "friends_yourname" and a table called "friends" 
	 * (Refer to model class to create the fields)
	 * 
	 *  Add 2 Sample entries
	 */
	
	// Create a Static method to return a DB connection
	
	public static Connection getConnection(String url, String username, String password) throws SQLException {
		if (conn == null || conn.isClosed()) {
			conn = DriverManager.getConnection(url, username, password);
		}
		return conn;
	}
	
	

}
