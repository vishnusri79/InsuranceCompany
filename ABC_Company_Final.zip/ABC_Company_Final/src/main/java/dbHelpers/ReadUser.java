package dbHelpers;

import java.io.InputStream;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import java.util.Properties;

import model.User;
import model.Claim;
import model.RegisteredProduct;

public class ReadUser {

	Connection conn;
	ResultSet rs;
	Statement statement;
	PreparedStatement pStmt;

	public ReadUser() {
		// TODO Auto-generated constructor stub
		Properties properties = new Properties();
		InputStream in;

		// conn = [call your static DB method]

		try {
			in = getClass().getResourceAsStream("dbConfig.properties");
			properties.load(in);

			String driver = properties.getProperty("jdbc.driver");

			if (driver != null) {
				Class.forName(driver);
			}
			String url = properties.getProperty("jdbc.url");
			String username = properties.getProperty("jdbc.username");
			String password = properties.getProperty("jdbc.password");

			conn = DB.getConnection(url, username, password);
			System.out.println("Connection Established");

		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public User doReadUserInfo(String username) throws SQLException {
		 User user = null;
		  String query = "SELECT * FROM users WHERE username = ?";
	        try ( PreparedStatement pstmt = conn.prepareStatement(query)) {
	            pstmt.setString(1, username);
	            ResultSet rs = pstmt.executeQuery();
	            if (rs.next()) {
	                user = new User();
	                user.setUserId(rs.getInt("user_id"));
	                user.setUsername(rs.getString("username"));
	                // Set other user details as needed
	            }
	        } catch (SQLException e) {
	            e.printStackTrace();
	            // Handle database errors
	        }
	        return user;

	}

	public List<RegisteredProduct> doReadUserProducts(String username) throws SQLException {
	        List<RegisteredProduct> registeredProducts = new ArrayList<>();

	        String query = "SELECT rp.registration_id, rp.serial_no, rp.purchase_date, rp.claims_left, p.product_name, p.category "
	                     + "FROM Registered_Products rp "
	                     + "INNER JOIN users u ON rp.user_id = u.user_id "
	                     + "INNER JOIN products p ON rp.product_id = p.product_id "
	                     + "WHERE u.username = ?";
	        
	        try (PreparedStatement stmt = conn.prepareStatement(query)) {
	            stmt.setString(1, username);
	            ResultSet rs = stmt.executeQuery();

	            while (rs.next()) {
	                RegisteredProduct registeredProduct = new RegisteredProduct();
	                registeredProduct.setRegistrationId(rs.getInt("registration_id"));
	                registeredProduct.setSerialNo(rs.getString("serial_no"));
	                registeredProduct.setPurchaseDate(rs.getDate("purchase_date").toLocalDate());
	                registeredProduct.setProductName(rs.getString("product_name"));
	                registeredProduct.setCategory(rs.getString("category"));
	                registeredProduct.setClaimsLeft(rs.getInt("claims_left"));
	                registeredProducts.add(registeredProduct);
	            }
	        } catch (SQLException e) {
	            e.printStackTrace();
	            throw e;
	        }

	        return registeredProducts;
	    }

	public List<Claim> doReadUserClaims(Integer userId) throws SQLException {
	    List<Claim> userClaims = new ArrayList<>();

	    String query = "SELECT c.claim_id, c.date_of_claim, c.description, c.status, c.approval_date, c.rejection_reason, "
	                 + "u.username, rp.registration_id, rp.serial_no, p.product_name, p.category "
	                 + "FROM Claims c "
	                 + "INNER JOIN Users u ON c.user_id = u.user_id "
	                 + "INNER JOIN Registered_Products rp ON c.registration_id = rp.registration_id "
	                 + "INNER JOIN Products p ON rp.product_id = p.product_id "
	                 + "WHERE u.user_id = ?";
	    
	    try (PreparedStatement stmt = conn.prepareStatement(query)) {
	        stmt.setInt(1, userId);
	        ResultSet rs = stmt.executeQuery();

	        while (rs.next()) {
	            Claim claim = new Claim();
	            claim.setClaimId(rs.getInt("claim_id"));
	            claim.setDateOfClaim(rs.getDate("date_of_claim").toLocalDate());
	            claim.setDescription(rs.getString("description"));
	            claim.setStatus(rs.getString("status"));
	            claim.setApprovalDate(rs.getDate("approval_date").toLocalDate());
	            claim.setRejectionReason(rs.getString("rejection_reason"));
	            claim.setRegisteredProduct(rs.getInt("registraion_id"));
	            
	            
	        
	            
	            

	            // Create User object
	            User user = new User();
	            user.setUsername(rs.getString("username"));
	            claim.setUser(userId);
	            

	           
	           

	            userClaims.add(claim);
	        }
	    } catch (SQLException e) {
	        e.printStackTrace();
	        throw e;
	    }

	    return userClaims;
	}



	

}
